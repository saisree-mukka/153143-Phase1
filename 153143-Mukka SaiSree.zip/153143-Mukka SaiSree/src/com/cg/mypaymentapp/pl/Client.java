package com.cg.mypaymentapp.pl;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.beans.Wallet;
import com.cg.mypaymentapp.service.WalletService;
import com.cg.mypaymentapp.service.WalletServiceImpl;


public class Client {
	
	private WalletService walletService;
	
	Map<String,Customer> map;
	   public Client() {
		
		map=new HashMap<String,Customer>();
		walletService=new WalletServiceImpl(map);
	}

	   void menu()
	   {
		   System.out.println("1)Create Account");
		   System.out.println("2)Show Balance");
		   System.out.println("3)Transfer the funds");
		   System.out.println("4)Deposit the amount");
		   System.out.println("5)Withdraw the amount");
		   System.out.println("6)Exit");
		   
		   Scanner sc=new Scanner(System.in);
		   System.out.println("Enter the choice");
		   int choice=sc.nextInt();
		   String mobileNumber=null;
		   Customer customer;
		   switch(choice) {
		   case 1:
			   System.out.println("Enter the mobile number");
			   mobileNumber=sc.next();
			   System.out.println("Enter the Name");
			   String name=sc.next();
			   System.out.println("Enter the amount");
			   BigDecimal amount=sc.nextBigDecimal();
			   //Customer customer;
			   customer=walletService.createAccount(name, mobileNumber, amount);
			   System.out.println(customer);
			   break;
		   case 2:
			   System.out.println("Enter the mobileNo");
			    mobileNumber=sc.next();
			   customer=walletService.showBalance(mobileNumber);
			   System.out.println("Current Balance:"+customer.getWallet().getBalance());
			   break;
		   case 3:
			   System.out.println("Enter the mobile number");
			    mobileNumber=sc.next();
			    System.out.println("Enter target mobile number");
			   String targetNumber=sc.next();
			   System.out.println("Enter the amount to be transferred");
			   BigDecimal transferAmount=sc.nextBigDecimal();
			   customer=walletService.fundTransfer(mobileNumber, targetNumber, transferAmount);
			   if(customer!=null) {
				   System.out.println("Transferred"+transferAmount+"to"+targetNumber+"from"+mobileNumber+"Updated balance is:"+customer.getWallet().getBalance());
			   }else {
				   System.out.println("Transfer Denied");
			   }
			   break;
		   case 4:
			   System.out.println("Enter the mobile number");
			    mobileNumber=sc.next();
			    System.out.println("Enter the amount to be deposited");
			    BigDecimal depositAmount=sc.nextBigDecimal();
			    customer=walletService.depositAmount(mobileNumber, depositAmount);
			    if(customer!=null) {
			    	System.out.println("The Amount was successfully deposited and The Updated Balance is:"+customer.getWallet().getBalance());
			    	
			    }else
			    {
			    	System.out.println("Transcation is Denied");
			    }
			    break;
		   case 5:
			   System.out.println("Enter the mobile number");
			    mobileNumber=sc.next();
			    System.out.println("Enter the amount to be withdrawn");
			    BigDecimal withdrawAmount=sc.nextBigDecimal();
			    customer=walletService.withdrawAmount(mobileNumber, withdrawAmount);
			    if(customer!=null) {
			    	System.out.println("The Amount was successfully withdrawn and The Updated Balance is:"+customer.getWallet().getBalance());
			    	
			    }else
			    {
			    	System.out.println("Transcation is Denied");
			    }
			    break;
		   case 6:
			   System.exit(0);
			   break;
			default:
				System.out.println("Please Enter the valid choice");
		   }
		   
	   }

	public static void main( String[] args ){
	        Client client=new Client();
	        while(true)
	       client.menu();
	    }
}
